from setuptools import setup

setup(name='design_config',
      version='0.0.2',
      description='Smart tiny config library for flask-like config',
      packages=['design_config'],
      author_email='artmihant@gmail.com',
      zip_safe=False)
